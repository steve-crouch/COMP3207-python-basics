word = 'tin'

print(word[0])
print(word[1])
print(word[2])
print(word[3])

